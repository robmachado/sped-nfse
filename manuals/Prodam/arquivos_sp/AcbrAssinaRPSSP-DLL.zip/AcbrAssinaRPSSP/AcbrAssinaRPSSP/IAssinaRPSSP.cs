﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;


namespace AcbrAssinaRPSSP
{
    [InterfaceType(ComInterfaceType.InterfaceIsDual), Guid("0095E40B-8274-4C73-AA46-B913A596C108")]
    public interface IAssinaRPSSP
    {
        string AssinarRPSSP(string serial, string original);
    }
}
